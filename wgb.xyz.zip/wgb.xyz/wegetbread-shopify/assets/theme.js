// Minimal JS for WEGETBREAD theme
console.log("WEGETBREAD theme loaded.");

// Optional: playful interactions for BUY ME buttons
document.addEventListener("DOMContentLoaded", function() {
    const buttons = document.querySelectorAll("button");
    buttons.forEach(btn => {
        btn.addEventListener("click", () => {
            alert("Just Flex It, WEGETBREAD!");
        });
    });
});