console.log("WEGETBREAD Shopify theme loaded.");
document.addEventListener("DOMContentLoaded", function() {
    const buttons = document.querySelectorAll("button");
    buttons.forEach(btn => {
        btn.addEventListener("click", () => {
            alert("Thanks for supporting WEGETBREAD!");
        });
    });
});