# WEGETBREAD Shopify Theme
Starter scaffold for WEGETBREAD Shopify theme.